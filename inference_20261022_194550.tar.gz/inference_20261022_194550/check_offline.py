"""Inference-only check: never opens serial/network or imports robot runtime."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np
import onnxruntime as ort


def main():
    p=argparse.ArgumentParser();p.add_argument('--model',choices=['walk1','decel_candidate'],default='walk1')
    args=p.parse_args();root=Path(__file__).resolve().parent
    for line in (root/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,f'Checksum mismatch: {name}'
    manifest=json.loads((root/'manifest.json').read_text());contract=json.loads((root/'interface.json').read_text())
    model=manifest['models'][args.model];path=root/model['file']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==model['sha256']
    options=ort.SessionOptions();options.intra_op_num_threads=options.inter_op_num_threads=1
    session=ort.InferenceSession(str(path),options,providers=['CPUExecutionProvider'])
    xinfo,yinfo=session.get_inputs()[0],session.get_outputs()[0]
    assert xinfo.shape==[1,61] and yinfo.shape==[1,14]
    assert xinfo.type==yinfo.type=='tensor(float)'
    # Fixed HOME/upright sensors and zero command, retaining raw action history.
    # These SYNTHETIC inputs do not represent a moving robot or gait test.
    x=np.zeros((1,61),dtype=np.float32);x[0,5]=-1
    values=[];maximum=0.;violations=[]
    home=np.asarray(contract['HOME_rad'],np.float32)
    ranges=np.asarray([contract['mjcf_joint_physical_ranges_rad'][n] for n in contract['joint_names']],np.float32)
    for _ in range(210):
        start=time.perf_counter_ns();raw=session.run(None,{xinfo.name:x})[0]
        elapsed=(time.perf_counter_ns()-start)/1e6
        assert raw.shape==(1,14) and np.isfinite(raw).all()
        maximum=max(maximum,float(np.abs(raw).max()))
        target=home+raw[0]
        violations.append(float(((target<ranges[:,0])|(target>ranges[:,1])).mean()))
        x[:,34:48]=raw
        values.append(elapsed)
    result={'model':args.model,'sha256':model['sha256'],'offline_check_passed':True,
            'runtime_version':ort.__version__,'normalization':'embedded; not applied externally',
            'input_shape':xinfo.shape,'output_shape':yinfo.shape,'samples_after_warmup':200,
            'inference_ms_p50':float(np.percentile(values[10:],50)),
            'inference_ms_p95':float(np.percentile(values[10:],95)),
            'inference_ms_max':max(values[10:]),'max_raw_action_abs_rad':maximum,
            'synthetic_target_outside_physical_fraction':float(np.mean(violations)),
            'scope':'current host CPU inference on synthetic fixed HOME sensors; not gait or bus/cycle qualification',
            'hardware_access':False,'approved_for_actuation':False}
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
